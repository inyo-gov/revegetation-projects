# Laws Revegetation Data - Essential Files

## Overview
This package contains the essential processed datasets from the Laws revegetation analysis. All intermediate processing files and redundant data have been removed.

## Files Included

### Main Analysis Results
- **analytical_results_table.csv** - Complete merged dataset with cover conversion and species attributes
- **parcel_summary.csv** - Parcel-level compliance statistics by year
- **species_summary_all_years.csv** - Species diversity and compliance across all years  
- **transect_summary.csv** - Transect-level cover analysis and compliance
- **comprehensive_compliance_summary.csv** - Complete compliance assessment for all parcels and years

### Reference Parcel Analysis
- **reference_parcel_summary.csv** - Reference parcel statistics and ATTO/ERNA thresholds
- **reference_atto_erna_analysis.csv** - Detailed analysis of policy-capped species
- **reference_based_atto_erna_thresholds.csv** - Calculated thresholds for species capping

### Spatial Data
- **laws_parcels.geojson** - GeoJSON boundaries for all Laws parcels
- **laws_transects.geojson** - GeoJSON point locations of all monitoring transects
- **laws_transects.csv** - Transect coordinates and metadata in CSV format

## Data Processing
All data has been processed through the following steps:
1. Raw data loading and cleaning
2. Species filtering using allowable species lists
3. Cover calculation: (hits / 200) × 100
4. Species-specific capping rules applied
5. Compliance assessment against 5 target criteria

## Contact
For questions about this data, contact the Inyo County Water Department.

